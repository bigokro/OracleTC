-- XML_CLOBS loading

declare 
  q dbms_xmlgen.ctxHandle;
  result clob;
  cursor cModules is select distinct  name from xml_stage order by 1;
begin
  for reg_module in cModules loop
    q := dbms_xmlgen.newContext ('select line, total_occur, total_time, text from xml_stage where name = ' 
      || '''' || reg_module.name || '''' || 'order by line');
    dbms_xmlgen.setRowTag(q, 'LINE');
    result:= dbms_xmlgen.getXML(q);
    insert into xml_clobs values (reg_module.name, result);
    dbms_xmlgen.closeContext(q);
    commit;
  end loop;
end;
/
call pkg_utils.PRC_DROP_INDEX('xml_clobs','ix_xml_clobs_01'); 
create index ix_xml_clobs_01 on xml_clobs (name);

-- PRC_EXPORT_CLOB clob stores a clob in an external file

CREATE OR REPLACE PROCEDURE PRC_EXPORT_CLOB (P_DATA IN CLOB
                            ,P_DIR  IN VARCHAR2
                            ,P_FILE IN VARCHAR2)
 IS

   t_out_file   UTL_FILE.file_type;
   t_buffer     VARCHAR2(32767);
   t_amount     BINARY_INTEGER := 32767;
   t_pos        INTEGER := 1;
   t_clob_len   INTEGER;
BEGIN
   t_clob_len := DBMS_LOB.GetLength(p_data);
   t_out_file := UTL_FILE.fOpen(p_dir, p_file, 'W', 32767);

   WHILE t_pos < t_clob_len LOOP
      DBMS_LOB.Read(p_data, t_amount, t_pos, t_buffer);
      UTL_FILE.Put(t_out_file, t_buffer);
      UTL_FILE.fFlush(t_out_file);
      t_pos := t_pos + t_amount;
   END LOOP;

   UTL_FILE.fClose(t_out_file);
EXCEPTION
   WHEN OTHERS THEN
      IF(UTL_FILE.Is_Open(t_out_file))THEN
         UTL_FILE.fClose(t_out_file);
      END IF;
      RAISE;
END;
/

-- Calls PRC_EXPORT_CLOB for every row in XML_STAGE

declare
  c clob;
  cursor cModules is
    select distinct name from xml_stage order by 1;
begin
  for reg_module in cModules loop
    select result into c from xml_clobs where name = reg_module.name;
    prc_export_clob(c, 'E:\TestCoverage\XML', reg_module.name || '.xml');
  end loop;
end;
/

drop procedure PRC_EXPORT_CLOB;
