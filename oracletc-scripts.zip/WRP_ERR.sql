prompt WRP_ERR.sql

@@ proftab.sql

create or replace procedure WRP_ERR
 as 
 begin 
-- PRC_LOG_AND_HANDLE invokes PRC_HANDLE
  PKG_ERR.PRC_LOG_AND_HANDLE (I_ERROR_NUMBER => 20260, I_ERROR_MESSAGE => 'Error while dropping index I_MKT_CURVE_POINT_1');
 end; 
/

delete XML_STAGE where name = 'PKG_ERR';

execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'WRP_ERR');
execute WRP_ERR
execute PKG_PROFILER.PRC_END_PROFILING

insert into xml_stage
      (name, line, total_occur, total_time, text)
select s.name name, s.line line, total_occur, p.total_time, s.text text 
  from user_source s, 
  (select u.unit_name, u.unit_type, d.line#, -1 total_occur, -1 total_time
  from plsql_profiler_data d, plsql_profiler_units u 
     where u.runid = d.runid 
     and u.unit_number = d.unit_number 
     and u.unit_type = 'PACKAGE BODY'
     and u.unit_name = 'PKG_ERR') p 
  where s.name = p.unit_name (+)   
  and s.line = p.line# (+)
  and s.type = p.unit_type (+) 
  and s.NAME = 'PKG_ERR'
  and S.type = 'PACKAGE BODY'
  ORDER BY NAME, LINE;

drop procedure WRP_ERR;


