prompt WRP_MKT_GET_PRECALC_VAL.sql

--Load profiler generated data

@@ Load_PLSQL_Profiler_tables.sql

create or replace procedure WRP_MKT_GET_PRECALC_VAL_Rep as
  cursor cPackages is
    select OBJECT_NAME
      from user_objects
     where object_name like 'PKG_MKT_GET_PRECALC_VAL%'
       and object_name <> 'PKG_MKT_GET_PRECALC_VAL_PS'  -- The only one touched in fits
       and object_type = 'PACKAGE BODY'
       and object_name not in (select distinct unit_name 
				from plsql_profiler_units 
				where unit_name like 'PKG_MKT_GET_PRECALC_VAL%')
     ORDER BY 1;

begin
  delete xml_stage where name like 'PKG_MKT_GET_PRECALC_VAL%' and name <> 'PKG_MKT_GET_PRECALC_VAL_PS';
  for l in cPackages loop
    insert into xml_stage
      (name, line, total_occur, total_time, text)
      select l.object_name name,
             s.line line,
             total_occur,
             p.total_time,
             s.text text
        from user_source s,
             (select distinct u.unit_name,
                     u.unit_type,
                     d.line#,
                     -1 total_occur,
                     -1 total_time
                from plsql_profiler_data d, plsql_profiler_units u
               where u.runid = d.runid
                 and u.unit_number = d.unit_number
                 and u.unit_type = 'PACKAGE BODY'
                 and u.unit_name = 'PKG_MKT_GET_PRECALC_VAL_PS') p
       where s.name = p.unit_name(+)
         and s.line = p.line#(+)
         and s.type = p.unit_type(+)
         and s.NAME = 'PKG_MKT_GET_PRECALC_VAL_PS'
         and S.type = 'PACKAGE BODY'
       ORDER BY NAME, LINE;
  end loop;
  commit;
exception
  when others then
    pkg_err.prc_handle(20060,
                       'Error during PKG_MKT_GET_PRECALC_VAL% replication');
end;
/


execute WRP_MKT_GET_PRECALC_VAL_Rep 

DROP PROCEDURE WRP_MKT_GET_PRECALC_VAL_Rep;