prompt WRP_VAL_EOD_REPORT_OPTION.sql

@@ proftab.sql


create or replace procedure WRP_VAL_EOD_REPORT_OPTION
 as 
   cur PKG_MKT_UTILS.P_REPORT_RESULT_DATA; 
 begin 
  PKG_VAL_EOD_REPORT_OPTION.PRC_GET_OPTION_REPORT ( 
     1,                     -- I_CURRENT_RUN_KEY 
     cur); 
close cur;
 end; 
 /

execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'WRP_VAL_EOD_REPORT_OPTION');
execute WRP_VAL_EOD_REPORT_OPTION
execute PKG_PROFILER.PRC_END_PROFILING

DELETE xml_stage WHERE NAME =  'PKG_VAL_EOD_REPORT_OPTION';

insert into xml_stage
      (name, line, total_occur, total_time, text)
select s.name name, s.line line, total_occur, p.total_time, s.text text 
  from user_source s, 
  (select u.unit_name, u.unit_type, d.line#, -1 total_occur, -1 total_time
  from plsql_profiler_data d, plsql_profiler_units u 
     where u.runid = d.runid 
     and u.unit_number = d.unit_number 
     and u.unit_type = 'PACKAGE BODY'
     and u.unit_name = 'PKG_VAL_EOD_REPORT_OPTION') p 
  where s.name = p.unit_name (+)   
  and s.line = p.line# (+)
  and s.type = p.unit_type (+) 
  and s.NAME = 'PKG_VAL_EOD_REPORT_OPTION'
  and S.type = 'PACKAGE BODY'
  ORDER BY NAME, LINE;

drop procedure WRP_VAL_EOD_REPORT_OPTION;


