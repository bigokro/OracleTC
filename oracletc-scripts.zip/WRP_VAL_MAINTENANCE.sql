prompt WRP_VAL_MAINTENANCE.sql

@@ proftab.sql

create or replace procedure WRP_VAL_MAINTENANCE
 as 
 begin 
-- PRC_CLEANUP_PRICING_RUNS invokes ALTER_FK and PRC_MDS_DROP_PARTITIONS
  PKG_VAL_MAINTENANCE.PRC_CLEANUP_PRICING_RUNS ('01/01/2001 12:00:00 00:00' 	-- I_EOD_ARCHIVE_DATE_STRING
); 
 end; 
/

execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'WRP_VAL_MAINTENANCE');
execute WRP_VAL_MAINTENANCE
execute PKG_PROFILER.PRC_END_PROFILING

delete xml_stage where NAME = 'PKG_VAL_MAINTENANCE';

insert into xml_stage
      (name, line, total_occur, total_time, text)
select s.name name, s.line line, total_occur, p.total_time, s.text text 
  from user_source s, 
  (select u.unit_name, u.unit_type, d.line#, -1 total_occur, -1 total_time
  from plsql_profiler_data d, plsql_profiler_units u 
     where u.runid = d.runid 
     and u.unit_number = d.unit_number 
     and u.unit_type = 'PACKAGE BODY'
     and u.unit_name = 'PKG_VAL_MAINTENANCE') p 
  where s.name = p.unit_name (+)   
  and s.line = p.line# (+)
  and s.type = p.unit_type (+) 
  and s.NAME = 'PKG_VAL_MAINTENANCE'
  and S.type = 'PACKAGE BODY'
  ORDER BY NAME, LINE;

drop procedure WRP_VAL_MAINTENANCE;


