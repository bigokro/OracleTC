prompt WRP_MKT_VAR_XXX.sql

--Load profiler generated data

@@ Load_PLSQL_Profiler_tables.sql

create or replace procedure WRP_MKT_VAR_XXX_Rep as
  cursor cPackages is
    select OBJECT_NAME
      from user_objects
     where object_name like 'PKG_MKT_VAR_%'
       and object_name <> 'PKG_MKT_VAR_PS'  -- The only one touched in fits
       and object_type = 'PACKAGE BODY'
     ORDER BY 1;

begin
  delete xml_stage where name like 'PKG_MKT_VAR_%' and name <> 'PKG_MKT_VAR_PS';
  for l in cPackages loop
    insert into xml_stage
      (name, line, total_occur, total_time, text)
      select l.object_name name,
             s.line line,
             total_occur,
             p.total_time,
             s.text text
        from user_source s,
             (select distinct u.unit_name,
                     u.unit_type,
                     d.line#,
                     -1 total_occur,
                     -1 total_time
                from plsql_profiler_data d, plsql_profiler_units u
               where u.runid = d.runid
                 and u.unit_number = d.unit_number
                 and u.unit_type = 'PACKAGE BODY'
                 and u.unit_name = 'PKG_MKT_VAR_PS') p
       where s.name = p.unit_name(+)
         and s.line = p.line#(+)
         and s.type = p.unit_type(+)
         and s.NAME = 'PKG_MKT_VAR_PS'
         and S.type = 'PACKAGE BODY'
       ORDER BY NAME, LINE;
  end loop;
  commit;
exception
  when others then
    pkg_err.prc_handle(20060,
                       'Error during PKG_MKT_VAR_% replication');
end;
/
set feed off
execute WRP_MKT_VAR_XXX_Rep
drop procedure WRP_MKT_VAR_XXX_Rep ; 
set feed on
