prompt WRP_MKT_VAR.sql

create or replace procedure WRP_MKT_VAR_Load as
  cReportResult        PKG_MKT_UTILS.P_REPORT_RESULT_DATA;
  v_valuation_date_str varchar2(100);
begin
  v_valuation_date_str := TO_CHAR(Systimestamp, 'MM/dd/yyyy hh24:mi:ss tzr');
  insert into MKT_MARKET_DATA_SET_ID
    (market_data_set_id,
     child_class,
     name,
     market_data_set_id_date,
     validation_out_of_date)
  values
    (1, 'a', 'mds1', Systimestamp, 1);

  INSERT INTO REF_SCENARIO_SET_DEFINITION
    (ref_scenario_set_definition_id,
     id,
     version_number,
     active,
     version_seq_num,
     version_latest,
     version_latest_status_id)
  VALUES
    (1, 1, 1, 1, 1, 1, 3);

  INSERT INTO REF_SCEN_SET_DEF_SCEN_DEFS
    (id, scen_set_def_scen_defs_id, pos)
  VALUES
    (1, 1, 1);

INSERT INTO REF_CFEA_ASSETS_PROX_MAPPING
    (REF_CFEA_ASSETS_PROX_MAPP_ID,
     id,
     version_number,
     active,
     version_seq_num,
     version_latest,
     version_latest_status_id)
  VALUES
    (1, 1, 1, 1, 1, 1, 3);

  PKG_MKT_VAR.PRC_MKT_GET_VAR_INSTR(1, -- I_MDS_ID
                                    1, -- I_SCENARIO_SET_ID
                                    v_valuation_date_str, -- I_VALUATION_DATE_STRING
                                    1, -- I_CURVE_TO_FEA_ASSET_MAPP_ID
                                    cReportResult -- IO_REPORT_RESULTS
                                    );
  close cReportResult;
  delete MKT_MARKET_DATA_SET_ID;
  DELETE REF_SCEN_SET_DEF_SCEN_DEFS;
  DELETE REF_SCENARIO_SET_DEFINITION;
  DELETE REF_CFEA_ASSETS_PROX_MAPPING;
  commit;
exception
  when others then
    pkg_err.prc_handle(20060, 'Error during PKG_MKT_var load');
end;
/

DELETE xml_stage WHERE NAME = 'PKG_MKT_VAR';

@@ proftab.sql

execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'WRP_MKT_VAR');
execute WRP_MKT_VAR_Load
execute PKG_PROFILER.PRC_END_PROFILING
set feed on

insert into xml_stage
      (name, line, total_occur, total_time, text)
      select s.name name,
             s.line line,
             total_occur,
             p.total_time,
             s.text text
        from user_source s,
             (select u.unit_name,
                     u.unit_type,
                     d.line#,
                     -1 total_occur,
                     -1 total_time
                from plsql_profiler_data d, plsql_profiler_units u
               where u.runid = d.runid
                 and u.unit_number = d.unit_number
                 and u.unit_type = 'PACKAGE BODY'
                 and u.unit_name = 'PKG_MKT_VAR') p
       where s.name = p.unit_name(+)
         and s.line = p.line#(+)
         and s.type = p.unit_type(+)
         and s.NAME = 'PKG_MKT_VAR'
         and S.type = 'PACKAGE BODY'
       ORDER BY NAME, LINE;

DROP PROCEDURE WRP_MKT_VAR_Load;







