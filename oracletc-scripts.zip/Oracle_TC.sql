/*************************************************************
Script Name  : OracleTC.sql
Created by   : Eduardo Morelli
Reviewed by  : none
Description  : Before loading data coming from migration, it is necessary to load several look up tables

Parameters   :
Preconditions: Hosting schema must have DBMS_PROFILER tables populated previously; 
		Also an Oracle directory pointing to E:\TestCoverage\XML must have been created
		UTL_DIR parameter must point to E:\TestCoverage\XML
		For more details about test coverage, please refer to http://subversion/repos/dewey/40. Product/4-Technical-documentation/Standards and Conventions/Oracle/PLSQL_Profiling.doc

Example usage: @http://subversion/repos/Sourcecode/xenon/branches/branch_rdbms_trade/rdbms.schema/src/oracle-scripts/data/LoadDomainData.sql
**************************************************************/

spool e:\saida.txt

@@ Load_PLSQL_Profiler_tables.sql

-- Previous cleaning
call pkg_utils.prc_drop_table ('xml_clobs', 'true');
call pkg_utils.prc_drop_table ('xml_stage', 'true');
call pkg_utils.prc_drop_table ('xml_stage_triggers_I', 'true');
call pkg_utils.prc_drop_table ('xml_stage_triggers_II', 'true'); 


-- XML_CLOBS will store one clob per line. Each line will correpond to a package, procedure or trigger
create table xml_clobs (name varchar2(30), result clob);


-- Staging area for procedures and package bodies

create table xml_stage as
 select name, line, max(total_ocurr) total_occur, sum(total_time) total_time, text from 
  (select s.name name, s.line line, p.total_occur total_ocurr, p.total_time total_time, s.text text 
  from user_source s, 
  (select u.unit_name, u.unit_type, d.line#, 
  d.total_occur, d.total_time/1000000 total_time 
  from plsql_profiler_data d, plsql_profiler_units u 
     where u.runid = d.runid 
     and u.unit_number = d.unit_number 
     and u.unit_type in ('PROCEDURE','PACKAGE BODY')) p 
  where s.name = p.unit_name (+)   
  and s.line = p.line# (+)
  and s.type = p.unit_type (+) 
  and s.type in ('PROCEDURE','PACKAGE BODY')) 
  group by name, line, text 
  order by 1,2;


-- Staging area for triggers. We need two tables due to dbms_profiler way to fill trigger executed lines

create table xml_stage_triggers_I as 
select u.unit_name,
       d.line# Line,
       max(d.total_occur) total_occur,
       sum(d.total_time) total_time
  from plsql_profiler_data d, plsql_profiler_units u
 where d.runid = u.runid
   and d.unit_number = u.unit_number
   and u.unit_type = 'TRIGGER'
 group by u.unit_name, d.line#
 order by 1, 2;

@@Triggers_Not_Being_Touched.sql

 
create table xml_stage_triggers_II as 
select x.unit_name, 
decode (x.line,1,x.line, x.line +
       (select min(line) - 1
           from user_source
          where name = x.unit_name
            and (text like '%BEGIN%' or text like '%DECLARE%'))) Line, total_occur, total_time
  from xml_stage_triggers_I x
order by 1, 2;


insert into xml_stage (name, line, total_occur, total_time, text)
 select us.name, us.line, total_occur, total_time/1000000 total_time, us.text
  from xml_stage_triggers_II x, user_source us
 where us.name = x.unit_name (+)
 and us.line = x.line (+)
 and us.type = 'TRIGGER'
 order by 1,2;

-- Index for performance purpose; Module name will be located quickly

create index ix_xml_stage_01 on xml_stage (name);

-- Updates Non Touched Packages During Fits and Fit4dbs
@@ WRP_MKT_GET_MAT_ADHOC.sql
@@ WRP_VAL_MAINTENANCE.sql
@@ WRP_VAL_EOD_REPORT_RAMIAS.sql
@@ WRP_VAL_EOD_REPORT_BORDER.sql
@@ WRP_VAL_EOD_REPORT_ALL_TRD_DMP.sql
@@ WRP_TRD_UTILS.sql
@@ WRP_TRD_GEN_LIQ_ORDER.sql
@@ WRP_REF_OBJ_IS_LATEST_VERS_CK.sql
@@ WRP_MKT_VAR.sql
@@ WRP_ERR.sql
@@ WRP_CCLASS_OBJ_IS_LAT_VERS_CK.sql
@@ WRP_MKT_GET_VAL.sql
@@ WRP_MKT_GET_PRECALC_VAL.sql
@@ WRP_MKT_VAR_XXX.sql
@@ WRP_VAL_EOD_REPORT_NUON_OTC.sql
@@ WRP_VAL_EOD_REPORT_OPTION.sql
@@ WRP_VAL_SCALE.sql
@@ WRP_VAL_AGG_PHYSICAL_FLOW.sql

DELETE XML_STAGE WHERE NAME = 'PKG_PROFILER';

COMMIT;

@@ Load_And_Export_CLOBS.sql

spool off