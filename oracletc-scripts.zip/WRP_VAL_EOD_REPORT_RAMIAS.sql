prompt WRP_VAL_EOD_REPORT_RAMIAS.sql

@@ proftab.sql

insert into MKT_MARKET_DATA_SET_ID (market_data_set_id,child_class, name, market_data_set_id_date, validation_out_of_date)
values (1, 'a', 'mds1', Systimestamp,1);

insert into VAL_PRICING_RUN (val_pricing_run_key, run_number, pnl_date, market_data_set_id, start_time)
values (1, 1, Systimestamp, 1, Systimestamp);


create or replace procedure WRP_VAL_EOD_REPORT_RAMIAS
 as 
   cur PKG_MKT_UTILS.P_REPORT_RESULT_DATA; 
 begin 
  PKG_VAL_EOD_REPORT_RAMIAS.PRC_GET_RAMIAS_REPORT ( 
     1,                     -- I_PRICING_RUN_KEY  
     cur); 
close cur;
 end; 
 /

execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'WRP_VAL_EOD_REPORT_RAMIAS');
execute WRP_VAL_EOD_REPORT_RAMIAS
execute PKG_PROFILER.PRC_END_PROFILING

delete xml_stage where NAME = 'PKG_VAL_EOD_REPORT_RAMIAS';

insert into xml_stage
      (name, line, total_occur, total_time, text)
select s.name name, s.line line, total_occur, p.total_time, s.text text 
  from user_source s, 
  (select u.unit_name, u.unit_type, d.line#, -1 total_occur, -1 total_time, d.runid runid
  from plsql_profiler_data d, plsql_profiler_units u 
     where u.runid = d.runid
     and u.unit_number = d.unit_number 
     and u.unit_type = 'PACKAGE BODY'
     and u.unit_name = 'PKG_VAL_EOD_REPORT_RAMIAS') p 
  where s.name = p.unit_name (+)   
  and s.line = p.line# (+)
  and s.type = p.unit_type (+) 
  and s.NAME = 'PKG_VAL_EOD_REPORT_RAMIAS'
  and S.type = 'PACKAGE BODY'
  ORDER BY NAME, LINE;

delete from VAL_PRICING_RUN ;
delete from MKT_MARKET_DATA_SET_ID ;
drop procedure WRP_VAL_EOD_REPORT_RAMIAS;



