-- Drop existing database link 
drop database link RIO.REGRESS.RDBMS.DEV.US.ORACLE.COM;
-- Create database link 
create database link RIO  connect to EMORELLI_FITTEST identified by sakonnet  using 'RIO';

@@proftab.sql

insert into plsql_profiler_runs (
runid, 
related_run, 
run_owner, 
run_date, 
run_comment, 
run_total_time, 
run_system_info, 
run_comment1, 
spare1
)
select 
runid, 
related_run, 
run_owner, 
run_date, 
run_comment, 
run_total_time, 
run_system_info, 
run_comment1, 
spare1
from plsql_profiler_runs@rio;

insert into plsql_profiler_units (
runid, 
unit_number, 
unit_type, 
unit_owner, 
unit_name, 
unit_timestamp, 
total_time, 
spare1, 
spare2
)
select
runid, 
unit_number, 
unit_type, 
unit_owner, 
unit_name, 
unit_timestamp, 
total_time, 
spare1, 
spare2
from plsql_profiler_units@rio;

insert into plsql_profiler_data (
runid, 
unit_number, 
line#, 
total_occur, 
total_time, 
min_time, 
max_time, 
spare1, 
spare2, 
spare3, 
spare4
)
select
runid, 
unit_number, 
line#, 
total_occur, 
total_time, 
min_time, 
max_time, 
spare1, 
spare2, 
spare3, 
spare4
from plsql_profiler_data@rio;

commit;

--@E:\TestCoverage\Oracle_TC.sql