prompt WRP_REF_OBJ_IS_LATEST_VERS_CK.sql

@@ proftab.sql

-- We will insert a row into REF_BANK, which will cause trigger execution. Those triggers call PKG_REF_OBJ_IS_LATEST_VERS_CK procedures/function
-- Therefore triggers from REF_BANK are being covered as well (T_REF_BANK_BSI_01, T_REF_BANK_BRI_01 and T_REF_BANK_ASI_01)


create or replace procedure WRP_REF_OBJ_IS_LATEST_VERS_CK
 as 
  i number;
 begin 
  insert into REF_BANK
(ref_bank_id, 
name, 
id, 
version_number, 
active, 
version_seq_num, 
version_latest, 
version_latest_status_id)
values(1,'Citybank', 1, 1, 1, 1, 1, 1);

delete REF_BANK;
commit;
end; 
/

execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'WRP_REF_OBJ_IS_LATEST_VERS_CK');
execute WRP_REF_OBJ_IS_LATEST_VERS_CK
execute PKG_PROFILER.PRC_END_PROFILING

DELETE xml_stage WHERE NAME =  'PKG_OBJ_IS_LATEST_VERSION_CK';

insert into xml_stage
      (name, line, total_occur, total_time, text)
select s.name name, s.line line, total_occur, p.total_time, s.text text 
  from user_source s, 
  (select u.unit_name, u.unit_type, d.line#, -1 total_occur, -1 total_time
  from plsql_profiler_data d, plsql_profiler_units u 
     where u.runid = d.runid 
     and u.unit_number = d.unit_number 
     and u.unit_type = 'PACKAGE BODY'
     and u.unit_name = 'PKG_OBJ_IS_LATEST_VERSION_CK') p 
  where s.name = p.unit_name (+)   
  and s.line = p.line# (+)
  and s.type = p.unit_type (+) 
  and s.NAME = 'PKG_OBJ_IS_LATEST_VERSION_CK'
  and S.type = 'PACKAGE BODY'
  ORDER BY NAME, LINE;

drop procedure WRP_REF_OBJ_IS_LATEST_VERS_CK;














