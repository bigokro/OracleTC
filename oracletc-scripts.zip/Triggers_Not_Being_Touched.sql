set echo off
set feed off

call pkg_utils.prc_drop_table ('REF_TABLES', 'TRUE');

create table REF_TABLES as
select distinct table_name
  from plsql_profiler_units u
 right outer join user_triggers p on p.trigger_name = u.unit_name
 where u.unit_name is null
   and trigger_name like 'T_REF%'
   and table_name not in ('REF_SECURITY_GROUP', 'REF_SECURITY_USER',
        'REF_PERSON', 'REF_BROKER');



CREATE OR REPLACE procedure PRC_FORCE_TRIGGER_PROFILING AS
  cursor cInserts is
    select 'insert into ' || TABLE_NAME || '(' || COLUMN_NAME ||
           ', ID, VERSION_NUMBER, ACTIVE, VERSION_SEQ_NUM, VERSION_LATEST_STATUS_ID) VALUES (1,1,1,1,1,1)' Insertion
      from user_IND_COLUMNS
     where table_name in (select table_name from REF_TABLES)
       and index_name like 'PK%';

  cursor cDeletes is
    select  'delete ' || table_name deletion
      from REF_TABLES;

begin
  for l in cInserts loop
    execute immediate (l.insertion);
  end loop;

  for l in cDeletes loop
    execute immediate (l.deletion);
  end loop;

  commit;
end;
/

@@ proftab.sql

execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'TRIGGERS NOT TOUCHED');

call PRC_FORCE_TRIGGER_PROFILING();

insert into REF_SECURITY_GROUP
  (REF_SECURITY_GROUP_ID,
   CHILD_CLASS,
   ID,
   VERSION_NUMBER,
   ACTIVE,
   VERSION_SEQ_NUM,
   VERSION_LATEST_STATUS_ID)
VALUES
  (1, 'child', 1, 1, 1, 1, 1);

insert into REF_SECURITY_USER
  (REF_SECURITY_USER_ID,
   ID,
   VERSION_NUMBER,
   ACTIVE,
   UNIQUE_LOGIN,
   USES_SAFE_WORD,
   IS_ADMIN,
   VERSION_SEQ_NUM,
   VERSION_LATEST_STATUS_ID)
VALUES
  (1, 1, 1, 1, 1, 1, 1, 1, 1);

 
insert into REF_PERSON
  (REF_PERSON_ID,
   CHILD_CLASS,
   ID,
   VERSION_NUMBER,
   ACTIVE,
   VERSION_SEQ_NUM,
   VERSION_LATEST_STATUS_ID)
VALUES
  (1, 'child', 1, 1, 1, 1, 1);  
  
insert into REF_BROKER
  (REF_BROKER_ID,
   CHILD_CLASS,
   ID,
   VERSION_NUMBER,
   ACTIVE,
   VERSION_SEQ_NUM,
   VERSION_LATEST_STATUS_ID)
VALUES
  (1, 'child', 1, 1, 1, 1, 1);    

insert into CNI_SETTLEMENT
  (SETTLEMENT_KEY,
   SETTLEMENT_ID,
   VERSION_NUMBER)
VALUES
  (1, 1, 1); 

insert into CNI_SETTLE_DOC
  (SETTLE_DOC_KEY,
   SETTLE_DOC_ID)
VALUES
  (1, 1); 

insert into CON_CONFIRMATION
  (CONFIRMATION_KEY,
   DEAL_KEY,
   DEFINITION_TYPE,
   VERSION_NUMBER,
   STATUS_ID)
VALUES
  (1, 1, 1, 1, 1); 

insert into TQC_TRADED_PRODUCT_DEF
  (TRADED_PRODUCT_DEFINITION_ID)
VALUES
  (1); 

insert into TRD_TRADE_HEADER_EXT
  (DEAL_ID)
values (1);

insert into TRD_TRADE_HEADER
  (TRADE_HEADER_KEY,
   CHILD_CLASS,
   PORTFOLIO_ID,
   PRINCIPAL_ID,
   TRADER_ID,
   DEAL_ID)
VALUES
  (1, 'abc', 1, 1, 1, 1); 

insert into TRD_TRADE_EXT
  (TRADE_ID)
values (1);

insert into TRD_TRADE
  (TRADE_KEY,
   TRADE_ID,
   TRADE_HEADER_KEY,
   VERSION_NUMBER,
   VERSION_SEQ_NUM)
VALUES
  (1, 1, 1, 1, 1); 

execute PKG_PROFILER.PRC_END_PROFILING
drop procedure PRC_FORCE_TRIGGER_PROFILING;

delete REF_SECURITY_GROUP;
delete REF_SECURITY_USER;
delete REF_PERSON;
delete REF_BROKER;
DELETE CNI_SETTLEMENT;
DELETE CNI_SETTLE_DOC;
DELETE TQC_TRADED_PRODUCT_DEF;
DELETE CON_CONFIRMATION;
DELETE TRD_TRADE;
DELETE TRD_TRADE_HEADER;
DELETE TRD_TRADE_EXT;
DELETE TRD_TRADE_HEADER_EXT;
commit;


INSERT into xml_stage_triggers_I(unit_name, line, total_occur, total_time) 
select u.unit_name,
       d.line# Line,
       -1 total_occur,
       -1 total_time
  from plsql_profiler_data d, plsql_profiler_units u
 where d.runid = u.runid
   and d.unit_number = u.unit_number
   and u.unit_type = 'TRIGGER'
 group by u.unit_name, d.line#
 order by 1, 2;

set echo off
set feed on



