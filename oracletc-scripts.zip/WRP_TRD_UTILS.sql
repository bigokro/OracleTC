prompt WRP_TRD_UTILS.sql

@@ proftab.sql


create or replace procedure WRP_TRD_UTILS
 as 
i number;
 begin 
  select PKG_TRD_UTILS.FNC_TRD_GET_LTEST_OR_VFIED_VER 
(1			-- I_TRADE_ID
)
into i from dual;
 end; 
/

execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'WRP_TRD_UTILS');
execute WRP_TRD_UTILS
execute PKG_PROFILER.PRC_END_PROFILING

DELETE xml_stage WHERE NAME =  'PKG_TRD_UTILS';

insert into xml_stage
      (name, line, total_occur, total_time, text)
select s.name name, s.line line, total_occur, p.total_time, s.text text 
  from user_source s, 
  (select u.unit_name, u.unit_type, d.line#, -1 total_occur, -1 total_time
  from plsql_profiler_data d, plsql_profiler_units u 
     where u.runid = d.runid 
     and u.unit_number = d.unit_number 
     and u.unit_type = 'PACKAGE BODY'
     and u.unit_name = 'PKG_TRD_UTILS') p 
  where s.name = p.unit_name (+)   
  and s.line = p.line# (+)
  and s.type = p.unit_type (+) 
  and s.NAME = 'PKG_TRD_UTILS'
  and S.type = 'PACKAGE BODY'
  ORDER BY NAME, LINE;

drop procedure WRP_TRD_UTILS;













