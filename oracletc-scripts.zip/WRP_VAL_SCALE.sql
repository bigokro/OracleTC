prompt WRP_VAL_SCALE.sql

set feed off
@@ proftab.sql
set feed on

execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'WRP_VAL_SCALE');

CALL PKG_VAL_SCALE_AI.PRC_SCALE_RESULTS(
1	--I_EOD_RUN_KEY
);

CALL PKG_VAL_SCALE_AT.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_ATAI.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_C.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_CBS.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_DT.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_FSTT.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_PC.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_PP.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_PPSTT.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_PSTTU.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_S.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_SP.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_TP.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_U.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_UDP.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_UP.PRC_SCALE_RESULTS(1);
CALL PKG_VAL_SCALE_US.PRC_SCALE_RESULTS(1);

execute PKG_PROFILER.PRC_END_PROFILING

delete xml_stage
where NAME LIKE 'PKG_VAL_SCALE_%'
and Name not in ('PKG_VAL_SCALE_P', 'PKG_VAL_SCALE_PRC', 'PKG_VAL_SCALE_PCPSTT', 'PKG_VAL_SCALE_PTT', 'PKG_VAL_SCALE_PS');
         

insert into xml_stage
      (name, line, total_occur, total_time, text)
      select s.name name,
             s.line line,
             total_occur,
             p.total_time,
             s.text text
        from user_source s,
             (select u.unit_name,
                     u.unit_type,
                     d.line#,
                     -1 total_occur,
                     -1 total_time
                from plsql_profiler_data d, plsql_profiler_units u
               where u.runid = d.runid
                 and u.unit_number = d.unit_number
                 and u.unit_type = 'PACKAGE BODY'
                 and u.unit_name LIKE 'PKG_VAL_SCALE_%'
		 and u.unit_name not in ('PKG_VAL_SCALE_P', 'PKG_VAL_SCALE_PRC', 'PKG_VAL_SCALE_PCPSTT', 'PKG_VAL_SCALE_PTT', 'PKG_VAL_SCALE_PS')) p
       where s.name = p.unit_name(+)
         and s.line = p.line#(+)
         and s.type = p.unit_type(+)
         and s.NAME LIKE 'PKG_VAL_SCALE_%'
	 and s.Name not in ('PKG_VAL_SCALE_P', 'PKG_VAL_SCALE_PRC', 'PKG_VAL_SCALE_PCPSTT', 'PKG_VAL_SCALE_PTT', 'PKG_VAL_SCALE_PS')
         and S.type = 'PACKAGE BODY'
       ORDER BY NAME, LINE;
commit;




