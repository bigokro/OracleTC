create table tc_not_touched_historical as
select object_name, sysdate when
  from (select DISTINCT p.object_name object_name
          from plsql_profiler_units u
         right outer join user_procedures p on p.object_name = u.unit_name
         where u.unit_name is null
        union
        select DISTINCT t.trigger_name object_name
          from plsql_profiler_units u
         right outer join user_triggers t on t.trigger_name = u.unit_name
         where u.unit_name is null)
 ORDER BY 1;

