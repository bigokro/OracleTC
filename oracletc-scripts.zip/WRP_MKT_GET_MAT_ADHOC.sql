prompt WRP_MKT_GET_MAT_ADHOC.sql

create or replace procedure WRP_MKT_GET_MAT_ADHOC_Load as
  cReportResult          PKG_MKT_UTILS.P_REPORT_RESULT_DATA;
  v_O_AS_OF_DATE         TIMESTAMP(0) WITH LOCAL TIME ZONE;
  v_valuation_date       TIMESTAMP(0) WITH LOCAL TIME ZONE;
  v_MARKET_DATA_SET_NAME VARCHAR2(200);
  v_PRICING_RUN_KEY      NUMBER(38);
  cReportErrors          PKG_MKT_UTILS.P_REPORT_RESULT_DATA;
begin

  insert into REF_MAT_DASHBOARD_DEFINITION
    (ref_mat_dashboard_def_id,
     id,
     version_number,
     active,
     version_seq_num,
     version_latest,
     version_latest_status_id)
  values
    (1, 1, 1, 1, 1, 1, 1);

  insert into MKT_MARKET_DATA_SET_ID
    (market_data_set_id,
     child_class,
     name,
     market_data_set_id_date,
     validation_out_of_date)
  values
    (1, 'a', 'mds1', Systimestamp, 1);

  insert into VAL_PRICING_RUN
    (val_pricing_run_key,
     run_number,
     pnl_date,
     market_data_set_id,
     start_time,
     materialized_dashboard_status)
  values
    (1, 1, Systimestamp, 1, Systimestamp, 'ACTIVE');

  insert into VAL_REFRESH_CYCLE_INFO
    (refresh_cycle_key,
     val_pricing_run_key,
     mat_dashboard_definition_id,
     valuation_date,
     as_of_date)
  values
    (1, 1, 1, Systimestamp, Systimestamp - 1 / 24);

  PKG_MKT_GET_MAT_ADHOC_AI.PRC_MKT_GET_PRECALC_VAL(1, -- I_MAT_DASHBOARD_DEF_ID
                                                   cReportResult, -- IO_REPORT_RESULT
                                                   v_O_AS_OF_DATE, -- O_AS_OF_DATE
                                                   v_VALUATION_DATE, -- O_VALUATION_DATE
                                                   v_MARKET_DATA_SET_NAME, -- O_MARKET_DATA_SET_NAME
                                                   v_PRICING_RUN_KEY, -- O_PRICING_RUN_KEY
                                                   cReportErrors -- O_REPORT_ERRORS
                                                   );
  close cReportResult;
  close cReportErrors;
  delete VAL_REFRESH_CYCLE_INFO;
  delete VAL_PRICING_RUN;
  delete MKT_MARKET_DATA_SET_ID;
  delete REF_MAT_DASHBOARD_DEFINITION;
  commit;
exception
  when others then
    pkg_err.prc_handle(20060,
                       'Error during PKG_MKT_GET_MAT_ADHOC% load');
end;
/


create or replace procedure WRP_MKT_GET_MAT_ADHOC_Rep as
  cursor cPackages is
    select OBJECT_NAME
      from user_objects
     where object_name like 'PKG_MKT_GET_MAT_ADHOC%'
       and object_name <> 'PKG_MKT_GET_MAT_ADHOC_AI'
       and object_type = 'PACKAGE BODY'
     ORDER BY 1;
begin
  DELETE xml_stage where name like 'PKG_MKT_GET_MAT_ADHOC_%';
  insert into xml_stage
    (name, line, total_occur, total_time, text)
    select s.name name, s.line line, total_occur, p.total_time, s.text text
      from user_source s,
           (select u.unit_name,
                   u.unit_type,
                   d.line#,
                   d.total_occur,
                   d.total_time
              from plsql_profiler_data d, plsql_profiler_units u
             where u.runid = d.runid
               and u.unit_number = d.unit_number
               and u.unit_type = 'PACKAGE BODY'
               and u.unit_name = 'PKG_MKT_GET_MAT_ADHOC_AI') p
     where s.name = p.unit_name(+)
       and s.line = p.line#(+)
       and s.type = p.unit_type(+)
       and s.NAME = 'PKG_MKT_GET_MAT_ADHOC_AI'
       and S.type = 'PACKAGE BODY'
     ORDER BY NAME, LINE;

  for l in cPackages loop
    insert into xml_stage
      (name, line, total_occur, total_time, text)
      select l.object_name name,
             s.line line,
             total_occur,
             p.total_time,
             s.text text
        from user_source s,
             (select u.unit_name,
                     u.unit_type,
                     d.line#,
                     -1 total_occur,
                     -1 total_time
                from plsql_profiler_data d, plsql_profiler_units u
               where u.runid = d.runid
                 and u.unit_number = d.unit_number
                 and u.unit_type = 'PACKAGE BODY'
                 and u.unit_name = 'PKG_MKT_GET_MAT_ADHOC_AI') p
       where s.name = p.unit_name(+)
         and s.line = p.line#(+)
         and s.type = p.unit_type(+)
         and s.NAME = 'PKG_MKT_GET_MAT_ADHOC_AI'
         and S.type = 'PACKAGE BODY'
       ORDER BY NAME, LINE;
  end loop;
  commit;
exception
  when others then
    pkg_err.prc_handle(20060,
                       'Error during PKG_MKT_GET_MAT_ADHOC% replication');
end;
/

set feed off
@@ proftab.sql
execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'WRP_MKT_GET_MAT_ADHOC');
execute WRP_MKT_GET_MAT_ADHOC_Load 
execute PKG_PROFILER.PRC_END_PROFILING
execute WRP_MKT_GET_MAT_ADHOC_Rep  
drop procedure WRP_MKT_GET_MAT_ADHOC_Load ;
drop procedure WRP_MKT_GET_MAT_ADHOC_Rep ;

set feed on



