prompt WRP_MKT_GET_VAL.sql

create or replace procedure WRP_MKT_GET_VAL_Load as
  V_QTY_ERRORS NUMBER;
begin
  INSERT INTO REF_SCENARIO_SET_DEFINITION
    (ref_scenario_set_definition_id,
     id,
     version_number,
     active,
     version_seq_num,
     version_latest,
     version_latest_status_id)
  VALUES
    (1, 1, 1, 1, 1, 1, 3);

  INSERT INTO REF_SCEN_SET_DEF_SCEN_DEFS
    (id, scen_set_def_scen_defs_id, pos)
  VALUES
    (1, 1, 1);

  PKG_MKT_GET_VAL_AI.PRC_GET_VAL_ERROR_COUNT(1, -- I_SCENARIO_SET_ID
                                             V_QTY_ERRORS -- O_ERROR_COUNT
                                             );
  PKG_MKT_GET_VAL_AT.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_ATAI.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_C.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_CBS.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_DT.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_FSTT.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_PC.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_PCPSTT.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_PP.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_PPSTT.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_PRC.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_PSTTU.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_PTT.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_S.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_SP.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_TP.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_TRD_MAT.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_U.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_UDP.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_UP.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);
  PKG_MKT_GET_VAL_US.PRC_GET_VAL_ERROR_COUNT(1, V_QTY_ERRORS);

  DELETE REF_SCEN_SET_DEF_SCEN_DEFS;
  DELETE REF_SCENARIO_SET_DEFINITION;
  commit;
exception
  when others then
    pkg_err.prc_handle(20060, 'Error during PKG_MKT_GET_VAL load');
end;
/

DELETE xml_stage 
WHERE NAME LIKE 'PKG_MKT_GET_VAL_%' 
AND NAME not in ('PKG_MKT_GET_VAL_P', 'PKG_MKT_GET_VAL_PS', 'PKG_MKT_GET_VAL_TRADE_DES', 'PKG_MKT_GET_VAL_EOD');

@@ proftab.sql

execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'WRP_MKT_GET_VAL');
execute WRP_MKT_GET_VAL_Load
execute PKG_PROFILER.PRC_END_PROFILING
set feed on

insert into xml_stage
      (name, line, total_occur, total_time, text)
      select s.name name,
             s.line line,
             total_occur,
             p.total_time,
             s.text text
        from user_source s,
             (select u.unit_name,
                     u.unit_type,
                     d.line#,
                     -1 total_occur,
                     -1 total_time
                from plsql_profiler_data d, plsql_profiler_units u
               where u.runid = d.runid
                 and u.unit_number = d.unit_number
                 and u.unit_type = 'PACKAGE BODY'
                 and u.unit_name LIKE 'PKG_MKT_GET_VAL_%'
		 and u.unit_name not in ('PKG_MKT_GET_VAL_P', 'PKG_MKT_GET_VAL_PS', 'PKG_MKT_GET_VAL_TRADE_DES', 'PKG_MKT_GET_VAL_EOD')) p
       where s.name = p.unit_name(+)
         and s.line = p.line#(+)
         and s.type = p.unit_type(+)
         and s.NAME like 'PKG_MKT_GET_VAL%'
	 and s.Name not in ('PKG_MKT_GET_VAL_P', 'PKG_MKT_GET_VAL_PS', 'PKG_MKT_GET_VAL_TRADE_DES', 'PKG_MKT_GET_VAL_EOD')
         and S.type = 'PACKAGE BODY'
       ORDER BY NAME, LINE;

DROP PROCEDURE WRP_MKT_GET_VAL_Load ;







