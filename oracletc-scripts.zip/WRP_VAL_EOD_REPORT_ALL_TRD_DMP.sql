prompt WRP_VAL_EOD_REPORT_ALL_TRD_DMP.sql

@@ proftab.sql


create or replace procedure WRP_VAL_EOD_REPORT_ALL_TRD_DMP
 as 
   cur PKG_MKT_UTILS.P_REPORT_RESULT_DATA; 
 begin 
  PKG_VAL_EOD_REPORT_ALL_TRD_DMP.PRC_GET_ALL_TRD_DUMP_REPORT( 
     1,                     -- I_CURRENT_RUN_KEY 
     1,                     -- I_START_SETTLEMENT_LONG 
     Systimestamp,   	    -- I_START_SETTLEMENT_DATE 
     1,      		    -- I_END_SETTLEMENT_LONG, 
     Systimestamp,   	    -- I_END_SETTLEMENT_DATE 
     cur); 
close cur;
 end; 
 /

execute PKG_PROFILER.PRC_START_PROFILING (I_COMMENT => 'WRP_VAL_EOD_REPORT_BORDER');
execute WRP_VAL_EOD_REPORT_ALL_TRD_DMP
execute PKG_PROFILER.PRC_END_PROFILING

DELETE xml_stage WHERE NAME =  'PKG_VAL_EOD_REPORT_ALL_TRD_DMP';

insert into xml_stage
      (name, line, total_occur, total_time, text)
select s.name name, s.line line, total_occur, p.total_time, s.text text 
  from user_source s, 
  (select u.unit_name, u.unit_type, d.line#, -1 total_occur, -1 total_time
  from plsql_profiler_data d, plsql_profiler_units u 
     where u.runid = d.runid 
     and u.unit_number = d.unit_number 
     and u.unit_type = 'PACKAGE BODY'
     and u.unit_name = 'PKG_VAL_EOD_REPORT_ALL_TRD_DMP') p 
  where s.name = p.unit_name (+)   
  and s.line = p.line# (+)
  and s.type = p.unit_type (+) 
  and s.NAME = 'PKG_VAL_EOD_REPORT_ALL_TRD_DMP'
  and S.type = 'PACKAGE BODY'
  ORDER BY NAME, LINE;

drop procedure WRP_VAL_EOD_REPORT_ALL_TRD_DMP;

